export const environment = {
    production: false,
    authURL: "https://canelaauth-production.up.railway.app/api/talentsoft/auth",
    secretKey: 'ThisIsASecretKey'
  };
  