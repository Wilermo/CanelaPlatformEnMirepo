export const environment = {
    production: true,
    authURL:'https://canelaauth-production.up.railway.app/api/talentsoft/auth',
    secretKey: 'ThisIsASecretKey'
  };
  
  