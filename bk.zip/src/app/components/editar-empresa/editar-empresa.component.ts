import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editar-empresa',
  templateUrl: './editar-empresa.component.html',
  styleUrl: './editar-empresa.component.css',
})
export class EditarEmpresaComponent implements OnInit {
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
}
