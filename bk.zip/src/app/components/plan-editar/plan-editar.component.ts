import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plan-editar',

  templateUrl: './plan-editar.component.html',
  styleUrl: './plan-editar.component.css',
})
export class PlanEditarComponent implements OnInit {
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
}
