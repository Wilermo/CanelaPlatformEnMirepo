import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-perfil-editar',
  templateUrl: './perfil-editar.component.html',
  styleUrl: './perfil-editar.component.css',
})
export class PerfilEditarComponent implements OnInit {
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
}
