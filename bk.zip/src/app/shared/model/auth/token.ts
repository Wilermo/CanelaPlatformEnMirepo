export interface TokenResponse{
    access_token:string,
    role:string
}