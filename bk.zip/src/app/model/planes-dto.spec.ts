import { PlanesDto } from './planes-dto';

describe('PlanesDto', () => {
  it('should create an instance', () => {
    expect(new PlanesDto()).toBeTruthy();
  });
});
