import { UsuarioPermisoDto } from './usuario-permiso-dto';

describe('UsuarioPermisoDto', () => {
  it('should create an instance', () => {
    expect(new UsuarioPermisoDto()).toBeTruthy();
  });
});
