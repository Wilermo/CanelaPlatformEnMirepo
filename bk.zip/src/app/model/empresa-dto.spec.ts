import { EmpresaDto } from './empresa-dto';

describe('EmpresaDto', () => {
  it('should create an instance', () => {
    expect(new EmpresaDto()).toBeTruthy();
  });
});
