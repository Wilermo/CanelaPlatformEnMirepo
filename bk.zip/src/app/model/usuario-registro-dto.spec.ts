import { UsuarioRegistroDto } from './usuario-registro-dto';

describe('UsuarioRegistroDto', () => {
  it('should create an instance', () => {
    expect(new UsuarioRegistroDto()).toBeTruthy();
  });
});
