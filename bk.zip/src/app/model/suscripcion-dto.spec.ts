import { SuscripcionDto } from './suscripcion-dto';

describe('SuscripcionDto', () => {
  it('should create an instance', () => {
    expect(new SuscripcionDto()).toBeTruthy();
  });
});
