export class MarketingDto {
  constructor(
    public nombre: string,
    public apellido: string,
    public email: string
  ) {}
}
