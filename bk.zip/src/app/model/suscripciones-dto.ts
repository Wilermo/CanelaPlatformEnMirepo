export class SuscripcionesDto {
}
