export class UsuarioPermisoDto {
  constructor(
    public firstname: string,
    public surname: string,
    public id: number
  ) {}
}
