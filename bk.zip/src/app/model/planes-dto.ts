export class PlanesDto {
  constructor(
    public namePlan: string | undefined,
    public description: string | undefined,
    public duration: string | undefined,
    public maxNumWorker: number | undefined,
    public bonuses: number | undefined
  ) {}
}
