import { MarketingDto } from './marketing-dto';

describe('MarketingDto', () => {
  it('should create an instance', () => {
    expect(new MarketingDto()).toBeTruthy();
  });
});
