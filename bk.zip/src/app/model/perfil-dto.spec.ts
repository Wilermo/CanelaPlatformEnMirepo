import { PerfilDto } from './perfil-dto';

describe('PerfilDto', () => {
  it('should create an instance', () => {
    expect(new PerfilDto()).toBeTruthy();
  });
});
