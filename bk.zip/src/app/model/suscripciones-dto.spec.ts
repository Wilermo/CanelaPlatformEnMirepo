import { SuscripcionesDto } from './suscripciones-dto';

describe('SuscripcionesDto', () => {
  it('should create an instance', () => {
    expect(new SuscripcionesDto()).toBeTruthy();
  });
});
